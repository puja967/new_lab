package com.cg.training.lab4.exercise1.service;

public class CurrentAccount extends Account {
  private double overDraftLimit;
  
  public void withdraw(double amt)
	{
		if(amt<overDraftLimit)
		    System.out.println("You Can Withdraw money");
		else
			System.out.println("Reached limit!.. Can't Withdraw money");
	}
  
}
