package com.cg.training.lab4.exercise3.service;

public class CD extends MediaItem {
private String genre;
private String artist;
@Override
public void addItem() {
	// TODO Auto-generated method stub
	
}
@Override
public void print() {
	// TODO Auto-generated method stub
	
}
@Override
public void checkIn() {
	// TODO Auto-generated method stub
	
}
@Override
public void checkOut() {
	// TODO Auto-generated method stub
	
}
@Override
public void equals() {
	// TODO Auto-generated method stub
	
}
}
