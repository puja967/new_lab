package com.cg.training.lab4.exercise3.service;

public abstract class WrittenItem extends Item{
private String author;
}
