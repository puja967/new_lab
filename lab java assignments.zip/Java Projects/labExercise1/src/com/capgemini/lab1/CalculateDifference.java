package com.capgemini.lab1;
import java.util.Scanner;
public class CalculateDifference {

	public static void main(String[] args) {
          Scanner sc=new Scanner(System.in);
          System.out.println("Enter a number");
          int n=sc.nextInt();
          calDifference(n);

	}
	public static void calDifference(int n)
	{
		int f=0,s=0;
		for(int i=0;i<=n;i++)
		{
			f=f+(i*i);
			s=s+i;
		}
		s=s*s;
		int difference=f-s;
		System.out.println("The Difference is "+difference);
	}

}
