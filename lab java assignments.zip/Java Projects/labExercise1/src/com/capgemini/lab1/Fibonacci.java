package com.capgemini.lab1;

import java.util.Scanner;

class Function{
	void nrcf(int a, int b, int c, int n)
	{
		for(int i=0;i<=n-2;i++)
		{
			c=a+b;
			a=b;
			b=c;
		}
		a=b=1;
		System.out.println("nth value in the series using non recursive function is:"+c);
	}
	void rcf(int a, int b, int c, int n)
	{
		if(n-2>0)
		{
			c=a+b;
			a=b;
			b=c;
			rcf(a,b,c,n-1);
			return;
		}
		  System.out.println("\nnth value in the series using recursive function is:"+c);
	}
}

class Fibonacci {

	public static void main(String[] args) {
		Function f=new Function();
		int n,a=1,b=1,c=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("\n Enter n value: ");
		n=sc.nextInt();
		f.nrcf(a,b,c,n);
		f.rcf(a,b,c,n);

	}

}
