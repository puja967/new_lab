package com.capgemini.lab1;

import java.util.Scanner;

public class TrafficLight {

	public static void main(String[] args) {
		  Scanner sc=new Scanner(System.in);
		  String value=sc.nextLine();
		  switch(value)
		  {
		  case "Red" : System.out.println("STOP");
		  break;
		  case "Yellow" : System.out.println("STOP");
		  break;
		  case "Green" :  System.out.println("GO");
			break;
			
		  }
;
		  
	}

}
