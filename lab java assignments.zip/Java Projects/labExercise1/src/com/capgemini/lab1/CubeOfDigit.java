package com.capgemini.lab1;
import java.util.Scanner;
import java.lang.*;
public class CubeOfDigit {

	public static void main(String[] args) {
		System.out.println("Enter the number");
		Scanner sc=new Scanner(System.in);
		
		int num=sc.nextInt();
		int sum=0;
		while(num!=0)
		{
			int digit= num%10;
			sum=sum+digit*digit*digit;
			num=num/10;
		}
       System.out.println("The sum of cubes of digit" +sum);
		
	}

}
