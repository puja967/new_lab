module labExercise2 {
}