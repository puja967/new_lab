package com.capgemini.lab2.exercise;

public class Exercise1 {
	public static int getSecondSmallest(int[] a, int n )
	{
		int temp;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++) {
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		return a[1];
	}
	public static void main(String[] args)
	{
		int a[]= {1,4,5,6,3,7};
		System.out.println("Second smallest element is:"+getSecondSmallest(a,6));
	}

}
